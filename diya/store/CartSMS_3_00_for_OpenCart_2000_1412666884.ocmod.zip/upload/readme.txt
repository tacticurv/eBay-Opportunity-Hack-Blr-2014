-------------------------------
MANUAL:
-------------------------------
-- EN: ------------------------
www.cart-sms.com/en/manual.html
-- CZ: ------------------------
www.cart-sms.com/cz/manual.html