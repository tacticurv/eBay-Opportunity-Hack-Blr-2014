<?php

// Heading
$_['heading_title']       = 'Cart SMS (TOPefekt)';

// Text
$_['text_module']         = 'Modules';
$_['text_success']        = 'Language has been changed.';
$_['text_content_top']    = 'Content Top';
$_['text_content_bottom'] = 'Content Bottom';
$_['text_column_left']    = 'Column Left';
$_['text_column_right']   = 'Column Right';

// Entry
$_['entry_language']        = 'Language:';


// Error
$_['error_permission']    = 'Warning: You do not have permission to modify OpenSMS module!';
$_['error_code']          = 'Code Required';

?>
