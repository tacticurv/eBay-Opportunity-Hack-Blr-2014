<?php
//define("v_refererID", "");

define("array_lang_names", "english|česky|slovensky|polski|italiano|srpski|русский|español|deutsch|türkçe|português|français|ελληνικά|svenska" );
define("array_langs", "en|cs|sk|pl|it|sr|ru|es|de|tr|pt|fr|el|sv");
 